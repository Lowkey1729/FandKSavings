-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2021 at 02:25 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e_wallet_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1),
(9, '2021_02_22_023438_create_wallets_table', 1),
(10, '2021_02_22_105820_add_to_users_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scopes` text,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('0176398cf179ffee5eb1d784038cebedb38a798bcbab4e4f033685750d144b7635dce65ad7fe7bee', 4, 1, 'MyApp', '[]', 0, '2021-02-22 15:25:28', '2021-02-22 15:25:28', '2022-02-22 16:25:28'),
('1a9346e62924d7f5f9933e5ee4816a0fe9db491fc5096ae6649598b0fc75c97c230287326858908e', 4, 1, 'MyApp', '[]', 0, '2021-02-22 15:25:25', '2021-02-22 15:25:25', '2022-02-22 16:25:25'),
('22e7bbe70868bf0dec21ac529de2bc31dcdce39daebe7761a0eed9df667b83448d2aef90aa58642b', 4, 1, 'MyApp', '[]', 0, '2021-02-22 15:31:25', '2021-02-22 15:31:25', '2022-02-22 16:31:25'),
('2906abfcca68f74a1a992ae755dd7171242c12791a0be7094c630ce3bf9a27be6bfb20858860b8a8', 4, 1, 'MyApp', '[]', 0, '2021-02-22 18:12:00', '2021-02-22 18:12:00', '2022-02-22 19:12:00'),
('4f661ac7494f76147cc939d6d7fc52d3eea718a7755e955a0655205be4bd44c30a110ea30d54570a', 4, 1, 'MyApp', '[]', 0, '2021-02-22 15:20:55', '2021-02-22 15:20:55', '2022-02-22 16:20:55'),
('54b85133995ddf6fa2d1316e9e7b2cfedae9807e441adcaec1bb30e88305ccded31cb8a8da8a4d31', 6, 1, 'MyApp', '[]', 0, '2021-02-22 22:15:12', '2021-02-22 22:15:12', '2022-02-22 23:15:12'),
('5918b38dfb18f0f288f0fe8513a573d646c009996e7ba9cf27f82487d428af3503f9058e3d479e5d', 4, 1, 'MyApp', '[]', 0, '2021-02-22 11:25:48', '2021-02-22 11:25:48', '2022-02-22 12:25:48'),
('75978c992275c360c32f4900fdfe46d8cabcff14e52abf954421997d677a8c00279be2188fc6b2ed', 7, 1, 'MyApp', '[]', 0, '2021-02-22 22:21:25', '2021-02-22 22:21:25', '2022-02-22 23:21:25'),
('7714229dfc33b16cea2d79b0c18b2dc85f265a1e6b54ae6008b64317003d98afc16eec0269a19668', 9, 1, 'MyApp', '[]', 0, '2021-02-22 22:25:24', '2021-02-22 22:25:24', '2022-02-22 23:25:24'),
('8aa7f030ea59a8c35fc1a01e55ef678d5588eaeebdceac0912368694afc609ca9922bfa1266987e4', 4, 1, 'MyApp', '[]', 0, '2021-02-22 11:41:18', '2021-02-22 11:41:18', '2022-02-22 12:41:18'),
('91d626cd185021e36ffcf9c8d9b3a454be1bd5c9dcadf406f3af69b0285e0ee4e5c9f5363d8a0f0e', 10, 1, 'MyApp', '[]', 0, '2021-02-22 22:30:00', '2021-02-22 22:30:00', '2022-02-22 23:30:00'),
('9334bb093fa76c358084624cf132c078d27032f39808fc5ee38c28b35555d503b9e8116cea01e5e9', 4, 1, 'MyApp', '[]', 0, '2021-02-22 13:26:07', '2021-02-22 13:26:07', '2022-02-22 14:26:07'),
('9ae6228d36cd92fbff97b16a4499288912af2df9dfdd5cd584a015c805d794e407bb231af7ef8fde', 4, 1, 'MyApp', '[]', 0, '2021-02-22 18:05:45', '2021-02-22 18:05:45', '2022-02-22 19:05:45'),
('bc688580ce64d7b214a74784b216cc801dfb87303e1e69103361d24d49d2916dad0ab7df9e813729', 5, 1, 'MyApp', '[]', 0, '2021-02-22 20:18:04', '2021-02-22 20:18:04', '2022-02-22 21:18:04'),
('d5cd68df0e09b93f1ad81c3c1e1aa41dd01b4133f13c94de7437397d98197bd6ad71b6e723ee4fed', 4, 1, 'MyApp', '[]', 0, '2021-02-22 13:21:59', '2021-02-22 13:21:59', '2022-02-22 14:21:59'),
('e00212dadc8fdc66852d00b0c4c0973b526dca30024625ad63ab6183a34189a816812bca4dce336f', 5, 1, 'MyApp', '[]', 0, '2021-02-22 20:02:24', '2021-02-22 20:02:24', '2022-02-22 21:02:24'),
('e2c80f6391fd1dc2cfbd04c905fb88911acd4aa83e5967808d6bc1bad3b5c673c85fa9ea4fa4d799', 4, 1, 'MyApp', '[]', 0, '2021-02-22 15:49:58', '2021-02-22 15:49:58', '2022-02-22 16:49:58'),
('e67e936bbd56adb384f5990e5d9b7eac4f7b5679c7802a97aec49fe4bc39352922775d63919acfa4', 8, 1, 'MyApp', '[]', 0, '2021-02-22 22:23:30', '2021-02-22 22:23:30', '2022-02-22 23:23:30'),
('ee293e08c9cb490590d5fe8251b366eb7a5c0363071081196e881f76b9ec2d8df0c783f8092b89c0', 4, 1, 'MyApp', '[]', 0, '2021-02-22 11:23:17', '2021-02-22 11:23:17', '2022-02-22 12:23:17');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'nxJtVaZidOPfg2MQQ4LM7K3O1ZnKHKi8774wl9Uk', NULL, 'http://localhost', 1, 0, 0, '2021-02-22 11:22:58', '2021-02-22 11:22:58'),
(2, NULL, 'Laravel Password Grant Client', 'sXXKLCXfvScZlcZXjWXUsBrhIHvfGYcIx4LMGsIG', 'users', 'http://localhost', 0, 1, 0, '2021-02-22 11:22:58', '2021-02-22 11:22:58');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-02-22 11:22:58', '2021-02-22 11:22:58');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `transaction_reference` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `transaction_reference`) VALUES
(4, 'Olarewaju', 'olarewajumojeed9@gmail.com', NULL, '$2y$10$wl3rqeBetnN/sB2HV/aAiumhMPtivLUP6KXnw49vuEdymrTnR2Cs6', NULL, '2021-02-22 11:23:16', '2021-02-22 18:48:03', '7ef59gbdud'),
(5, 'olami', 'ola@gmail.com', NULL, '$2y$10$Y5tTx11MBh9agUeOhhOXt.Fya53d.68Lvcj8dejuqUE5B8tlz6Sja', NULL, '2021-02-22 20:02:23', '2021-02-22 20:36:44', 'ezogiwpx4w'),
(6, 'olami', 'olar@gmail.com', NULL, '$2y$10$4J2Rdj2pAbD.yXht/xn1XOuTVF442/Km0kgMTYjxYbjKBQws89BX2', NULL, '2021-02-22 22:15:09', '2021-02-22 22:15:09', NULL),
(7, 'olami', 'olr@gmail.com', NULL, '$2y$10$ab7jn56sR9XfdbhOk.wDYuU.vjJP.jpo9xaVj4poN1K/H1r.Ghqm.', NULL, '2021-02-22 22:21:25', '2021-02-22 22:21:25', NULL),
(8, 'olami', 'klr@gmail.com', NULL, '$2y$10$v6w0MHDrwmvM8PO9IxH9eehdsZclyscZikm0MwXsH4JaOOix7VOFO', NULL, '2021-02-22 22:23:29', '2021-02-22 22:23:29', NULL),
(9, 'olami', 'rose@gmail.com', NULL, '$2y$10$NygayWCIA6fyPZ0sd77kk.oUtIUDdiA/t15EfwcKapFNZHbW5.yBi', NULL, '2021-02-22 22:25:24', '2021-02-22 22:25:24', NULL),
(10, 'olami', 'roe@gmail.com', NULL, '$2y$10$jEirf.RNfimhuBx7kiTxJey/dsQt7BND5bLaJBWOVW8ioECBjM/D.', NULL, '2021-02-22 22:30:00', '2021-02-22 22:30:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `balance` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `last_transcation` timestamp NULL DEFAULT NULL,
  `wallet_account_number` bigint(20) UNSIGNED DEFAULT NULL,
  `details_of_last_transaction` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`id`, `user_id`, `balance`, `last_transcation`, `wallet_account_number`, `details_of_last_transaction`, `created_at`, `updated_at`) VALUES
(7, 4, 1438, '2021-02-22 19:02:39', 10637496, ' Funded your wallet.', '2021-02-22 19:02:09', '2021-02-22 20:32:54'),
(8, 5, 1970, '2021-02-22 20:37:36', 11039011, 'Funded wallet', '2021-02-22 20:10:09', '2021-02-22 20:37:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wallets_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `wallets`
--
ALTER TABLE `wallets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `wallets`
--
ALTER TABLE `wallets`
  ADD CONSTRAINT `wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
